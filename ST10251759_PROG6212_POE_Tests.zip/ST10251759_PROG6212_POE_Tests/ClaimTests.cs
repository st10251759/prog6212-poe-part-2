﻿/*
 --------------------------------Student Information----------------------------------
 STUDENT NO.: ST10251759
 Name: Cameron Chetty
 Course: BCAD Year 2
 Module: Programming 2B
 Module Code: CLDV6212
 Assessment: Portfolio of Evidence (POE) Part 2
 Github repo link: https://github.com/st10251759/prog6212-poe-part-2
 --------------------------------Student Information----------------------------------

 ==============================Code Attribution==================================

 Attributes
 Author: Fatima Shaik
 Link: https://github.com/fb-shaik/PROG6212-Group1-2024/tree/main/TaskManager_Attributes_demo/TaskManager_Attributes_demo
 Date Accessed: 11 October 2024

 MVC APP
 Author: Fatima Shaik
 Link: https://github.com/fb-shaik/PROG6212-Group1-2024/blob/main/EmployeeLeaveManagement_G1.zip
 Date Accessed: 11 October 2024

 ==============================Code Attribution==================================

 */

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ST10251759_PROG6212_POE.Models;

namespace ST10251759_PROG6212_POE_Tests
{
    [TestFixture]
    public class ClaimTests
    {
        [Test]
        public void ValidClaim_ShouldNotHaveValidationErrors()
        {
            // Arrange
            var claim = new Claim
            {
                HoursWorked = 10, // Valid hours worked
                HourlyRate = 200, // Valid hourly rate
                TotalAmount = 2000, // Total amount calculated correctly (HoursWorked * HourlyRate)
                Notes = "This is a valid claim.", // Valid notes
                DateSubmitted = DateTime.Now, // Current date for valid submission
                StartDate = DateTime.Now.AddDays(-10), // Valid start date
                EndDate = DateTime.Now // Valid end date
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(claim);
            var isValid = Validator.TryValidateObject(claim, validationContext, validationResults, true);

            // Assert
            Assert.IsTrue(isValid);
            Assert.IsEmpty(validationResults);
        }

        [Test]
        public void Claim_WithInvalidHoursWorked_ShouldHaveValidationErrors()
        {
            // Arrange
            var claim = new Claim
            {
                HoursWorked = 0, // Invalid value (must be greater than 0)
                HourlyRate = 200, // Valid hourly rate
                TotalAmount = 0, // Incorrect value, but not tested here
                Notes = "Invalid claim due to hours worked.", // Valid notes
                DateSubmitted = DateTime.Now, // Current date for submission
                StartDate = DateTime.Now.AddDays(-5), // Valid start date
                EndDate = DateTime.Now // Valid end date
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(claim);
            var isValid = Validator.TryValidateObject(claim, validationContext, validationResults, true);

            // Assert
            Assert.IsFalse(isValid);
            Assert.IsNotEmpty(validationResults);
            Assert.IsTrue(validationResults.Exists(v => v.ErrorMessage == "Hours Worked must be between 1 and 150."));
        }

        [Test]
        public void Claim_WithInvalidHourlyRate_ShouldHaveValidationErrors()
        {
            // Arrange
            var claim = new Claim
            {
                HoursWorked = 10, // Valid hours worked
                HourlyRate = 40, // Invalid value (must be between 200 and 1000)
                TotalAmount = 400, // Incorrect value, but not tested here
                Notes = "Invalid claim due to hourly rate.", // Valid notes
                DateSubmitted = DateTime.Now, // Current date for submission
                StartDate = DateTime.Now.AddDays(-5), // Valid start date
                EndDate = DateTime.Now // Valid end date
            };

            // Act
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(claim);
            var isValid = Validator.TryValidateObject(claim, validationContext, validationResults, true);

            // Assert
            Assert.IsFalse(isValid);
            Assert.IsNotEmpty(validationResults);
            Assert.IsTrue(validationResults.Exists(v => v.ErrorMessage == "Hourly Rate must be between 200 and 1000."));
        }



    }
}
