﻿/*
 --------------------------------Student Information----------------------------------
 STUDENT NO.: ST10251759
 Name: Cameron Chetty
 Course: BCAD Year 2
 Module: Programming 2B
 Module Code: CLDV6212
 Assessment: Portfolio of Evidence (POE) Part 2
 Github repo link: https://github.com/st10251759/prog6212-poe-part-2
 --------------------------------Student Information----------------------------------

 ==============================Code Attribution==================================

 Attributes
 Author: Fatima Shaik
 Link: https://github.com/fb-shaik/PROG6212-Group1-2024/tree/main/TaskManager_Attributes_demo/TaskManager_Attributes_demo
 Date Accessed: 11 October 2024

 MVC APP
 Author: Fatima Shaik
 Link: https://github.com/fb-shaik/PROG6212-Group1-2024/blob/main/EmployeeLeaveManagement_G1.zip
 Date Accessed: 11 October 2024

 ==============================Code Attribution==================================

 */

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ST10251759_PROG6212_POE.Models;

namespace ST10251759_PROG6212_POE_Tests
{
    [TestFixture]
    public class ClaimTests
    {
        [Test]
        public void ValidClaim_ShouldNotHaveValidationErrors()
        {
            // Arrange
            // Creating a valid Claim object with proper values
            var claim = new Claim
            {
                HoursWorked = 10,  // Valid hours worked
                HourlyRate = 200,  // Valid hourly rate
                TotalAmount = 1000, // Total amount calculated correctly (HoursWorked * HourlyRate)
                Notes = "This is a valid claim.", // Valid notes
                DateSubmitted = DateTime.Now // Current date for valid submission
            };

            // Act
            // Prepare to validate the claim object
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(claim);
            // Try to validate the object
            var isValid = Validator.TryValidateObject(claim, validationContext, validationResults, true);

            // Assert
            // Ensure the claim is valid and has no validation errors
            Assert.IsTrue(isValid); // Expect isValid to be true
            Assert.IsEmpty(validationResults); // Expect validationResults to be empty
        }

        [Test]
        public void Claim_WithInvalidHoursWorked_ShouldHaveValidationErrors()
        {
            // Arrange
            // Creating a Claim object with invalid hours worked (0 hours)
            var claim = new Claim
            {
                HoursWorked = 0, // Invalid value (must be greater than 0)
                HourlyRate = 100, // Valid hourly rate
                TotalAmount = 1000, // This value may be incorrect but not validated in this case
                Notes = "Invalid claim due to hours worked.", // Valid notes
                DateSubmitted = DateTime.Now // Current date for submission
            };

            // Act
            // Prepare to validate the claim object
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(claim);
            // Try to validate the object
            var isValid = Validator.TryValidateObject(claim, validationContext, validationResults, true);

            // Assert
            // Ensure the claim is invalid and has validation errors
            Assert.IsFalse(isValid); // Expect isValid to be false
            Assert.IsNotEmpty(validationResults); // Expect validationResults to have errors
            Assert.IsTrue(validationResults.Exists(v => v.ErrorMessage == "Hours Worked must be between 1 and 150.")); // Expect specific error message
        }

        [Test]
        public void Claim_WithInvalidHourlyRate_ShouldHaveValidationErrors()
        {
            // Arrange
            // Creating a Claim object with an invalid hourly rate (less than the minimum allowed)
            var claim = new Claim
            {
                HoursWorked = 10, // Valid hours worked
                HourlyRate = 40, // Invalid value (must be between 200 and 1000)
                TotalAmount = 400, // This value may be incorrect but not validated in this case
                Notes = "Invalid claim due to hourly rate.", // Valid notes
                DateSubmitted = DateTime.Now // Current date for submission
            };

            // Act
            // Prepare to validate the claim object
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(claim);
            // Try to validate the object
            var isValid = Validator.TryValidateObject(claim, validationContext, validationResults, true);

            // Assert
            // Ensure the claim is invalid and has validation errors
            Assert.IsFalse(isValid); // Expect isValid to be false
            Assert.IsNotEmpty(validationResults); // Expect validationResults to have errors
            Assert.IsTrue(validationResults.Exists(v => v.ErrorMessage == "Hourly Rate must be between 200 and 1000.")); // Expect specific error message
        }

        [Test]
        public void Claim_WithFutureDateSubmitted_ShouldHaveValidationErrors()
        {
            // Arrange
            // Creating a Claim object with a future submission date
            var claim = new Claim
            {
                HoursWorked = 10, // Valid hours worked
                HourlyRate = 100, // Valid hourly rate
                TotalAmount = 1000, // Total amount calculated correctly (HoursWorked * HourlyRate)
                Notes = "This claim has a future submission date.", // Valid notes
                DateSubmitted = DateTime.Now.AddDays(1) // Future date (invalid)
            };

            // Act
            // Prepare to validate the claim object
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(claim);
            // Try to validate the object
            var isValid = Validator.TryValidateObject(claim, validationContext, validationResults, true);

            // Assert
            // Ensure the claim is invalid and has validation errors
            Assert.IsFalse(isValid); // Expect isValid to be false
            Assert.IsNotEmpty(validationResults); // Expect validationResults to have errors
            Assert.IsTrue(validationResults.Exists(v => v.ErrorMessage == "Date Submitted cannot be in the future.")); // Expect specific error message
        }

        [Test]
        public void Claim_WithDateNotInCurrentOrPreviousMonth_ShouldHaveValidationErrors()
        {
            // Arrange
            // Creating a Claim object with a submission date not in the current or previous month
            var claim = new Claim
            {
                HoursWorked = 10, // Valid hours worked
                HourlyRate = 100, // Valid hourly rate
                TotalAmount = 1000, // Total amount calculated correctly (HoursWorked * HourlyRate)
                Notes = "Invalid submission date.", // Valid notes
                DateSubmitted = new DateTime(DateTime.Now.Year, DateTime.Now.Month - 2, 1) // Submission date is two months ago (invalid)
            };

            // Act
            // Prepare to validate the claim object
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(claim);
            // Try to validate the object
            var isValid = Validator.TryValidateObject(claim, validationContext, validationResults, true);

            // Assert
            // Ensure the claim is invalid and has validation errors
            Assert.IsFalse(isValid); // Expect isValid to be false
            Assert.IsNotEmpty(validationResults); // Expect validationResults to have errors
            Assert.IsTrue(validationResults.Exists(v => v.ErrorMessage == "Date Submitted can only be from the current month or previous month.")); // Expect specific error message
        }
    }
}
