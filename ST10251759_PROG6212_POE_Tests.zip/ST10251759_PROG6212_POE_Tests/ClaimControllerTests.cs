﻿/*
 --------------------------------Student Information----------------------------------
 STUDENT NO.: ST10251759
 Name: Cameron Chetty
 Course: BCAD Year 2
 Module: Programming 2B
 Module Code: CLDV6212
 Assessment: Portfolio of Evidence (POE) Part 2
 Github repo link: https://github.com/st10251759/prog6212-poe-part-2
 --------------------------------Student Information----------------------------------

 ==============================Code Attribution==================================

 Attributes
 Author: Fatima Shaik
 Link: https://github.com/fb-shaik/PROG6212-Group1-2024/tree/main/TaskManager_Attributes_demo/TaskManager_Attributes_demo
 Date Accessed: 11 October 2024

 MVC APP
 Author: Fatima Shaik
 Link: https://github.com/fb-shaik/PROG6212-Group1-2024/blob/main/EmployeeLeaveManagement_G1.zip
 Date Accessed: 11 October 2024

 ==============================Code Attribution==================================

 */

using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using ST10251759_PROG6212_POE.Controllers;
using ST10251759_PROG6212_POE.Data;
using ST10251759_PROG6212_POE.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10251759_PROG6212_POE_Tests
{//namepsace begin
    // TestFixture attribute indicates that this class contains test methods
    [TestFixture]
    public class ClaimControllerTests
    {
        // Declaring private fields for the controller, context, user manager, and test user
        private ClaimController _controller; // Instance of the ClaimController being tested
        private Prog6212DbContext _context; // In-memory database context for testing
        private UserManager<IdentityUser> _userManager; // User manager to manage identity users
        private IdentityUser _testUser; // Test user instance for performing tests

        // SetUp attribute indicates that this method runs before each test method
        [SetUp]
        public void Setup()
        {
            // Configuring the in-memory database for testing with a unique name for each run
            var options = new DbContextOptionsBuilder<Prog6212DbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase" + Guid.NewGuid().ToString()) // Ensure a unique database name
                .Options; // Creating options for the context

            _context = new Prog6212DbContext(options); // Initializing the in-memory database context
            _userManager = CreateUserManager(); // Creating a mock UserManager instance

            // Initializing a test user with a unique ID and username
            _testUser = new IdentityUser
            {
                Id = Guid.NewGuid().ToString(), // Generating a unique ID for the test user
                UserName = "testuser@example.com" // Setting a sample username for the test user
            };

            // Adding the test user to the in-memory database context
            _context.Users.Add(_testUser);
            _context.SaveChanges(); // Saving changes to the in-memory database

            // Initializing the ClaimController with the context, user manager, and null for the third parameter
            _controller = new ClaimController(_context, _userManager, null);
        }

        // TearDown attribute indicates that this method runs after each test method
        [TearDown]
        public void Dispose()
        {
            _context?.Dispose(); // Disposing of the context if it is not null to free resources
            _controller?.Dispose(); // Disposing of the controller instance
            _userManager?.Dispose(); // Disposing of the user manager instance
        }

        // Test method for validating a correctly formatted PDF document
        [Test]
        public void IsValidPdfDocument_ValidPdf_ReturnsTrue()
        {
            // Arrange: Creating a valid PDF file as a FormFile object
            var validFile = new FormFile(new MemoryStream(new byte[100]), 0, 100, "Data", "valid.pdf")
            {
                Headers = new HeaderDictionary(), // Initializing headers for the FormFile
                ContentType = "application/pdf" // Setting the content type to PDF
            };

            // Act: Calling the IsValidDocument method with the valid file
            var result = _controller.IsValidDocument(validFile);

            // Assert: Verifying that the result is true, indicating the document is valid
            Assert.IsTrue(result);
        }

        // Test method for validating an incorrectly formatted PDF document
        [Test]
        public void IsValidPdfDocument_InvalidPdf_ReturnsFalse()
        {
            // Arrange: Creating an invalid file (not a PDF)
            var invalidFile = new FormFile(new MemoryStream(new byte[100]), 0, 100, "Data", "invalid.txt")
            {
                Headers = new HeaderDictionary(), // Initializing headers for the FormFile
                ContentType = "text/plain" // Setting the content type to plain text
            };

            // Act: Calling the IsValidDocument method with the invalid file
            var result = _controller.IsValidDocument(invalidFile);

            // Assert: Verifying that the result is false, indicating the document is invalid
            Assert.IsFalse(result);
        }

        // Test method for validating a file that exceeds the maximum size limit
        [Test]
        public void IsValidPdfDocument_FileTooLarge_ReturnsFalse()
        {
            // Arrange: Creating a large PDF file as a FormFile object (20 MB)
            var largeFile = new FormFile(new MemoryStream(new byte[20 * 1024 * 1024]), 0, 20 * 1024 * 1024, "Data", "large.pdf") // 20 MB
            {
                Headers = new HeaderDictionary(), // Initializing headers for the FormFile
                ContentType = "application/pdf" // Setting the content type to PDF
            };

            // Act: Calling the IsValidDocument method with the large file
            var result = _controller.IsValidDocument(largeFile);

            // Assert: Verifying that the result is false, indicating the file size exceeds the limit
            Assert.IsFalse(result);
        }

        // Helper method to create a mock UserManager<IdentityUser>
        private UserManager<IdentityUser> CreateUserManager()
        {
            // Creating a mock object for IUserStore<IdentityUser>
            var store = new Mock<IUserStore<IdentityUser>>(); // Mocking the user store interface
            // Initializing the UserManager with the mocked store and other parameters set to null
            var userManager = new UserManager<IdentityUser>(
                store.Object, // Passing the mocked store object
                null, // Other parameters can be set as needed but are null for testing
                null,
                null,
                null,
                null,
                null,
                null,
                null
            );

            return userManager; // Returning the mocked UserManager instance
        }
    }
}//namespace end
