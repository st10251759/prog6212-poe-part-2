﻿/*
 --------------------------------Student Information----------------------------------
 STUDENT NO.: ST10251759
 Name: Cameron Chetty
 Course: BCAD Year 2
 Module: Programming 2B
 Module Code: PROG6212
 Assessment: Portfolio of Evidence (POE) Part 3
 Github repo link: https://github.com/st10251759/prog6212-poe-part-2
 --------------------------------Student Information----------------------------------

 ==============================Code Attribution==================================

 Attributes
 Author: Fatima Shaik
 Link: https://github.com/fb-shaik/PROG6212-Group1-2024/tree/main/TaskManager_Attributes_demo/TaskManager_Attributes_demo
 Date Accessed: 11 October 2024

 MVC APP
 Author: Fatima Shaik
 Link: https://github.com/fb-shaik/PROG6212-Group1-2024/blob/main/EmployeeLeaveManagement_G1.zip
 Date Accessed: 11 October 2024

 ==============================Code Attribution==================================

 */

// Importing necessary namespaces and dependencies
using ST10251759_PROG6212_POE.Models; // Reference to the models used in the main application, specifically the Report model
using System;
using System.Collections.Generic; // Provides support for collections, like List<T>
using System.ComponentModel.DataAnnotations; // Enables validation attributes, such as Required and CustomValidation
using System.Linq; // Provides LINQ functionality for querying collections
using System.Text; // Provides support for text encoding and manipulation
using System.Threading.Tasks; // Supports asynchronous programming

namespace ST10251759_PROG6212_POE_Tests // Defines the namespace for unit tests related to the main application's models and logic
{
    // Indicates that this class contains NUnit test cases
    [TestFixture]
    public class ReportTest
    {
        // Test to verify that a Report with missing required fields results in validation errors
        [Test]
        public void Report_WithMissingRequiredFields_ShouldHaveValidationErrors()
        {
            // Arrange
            // Creating a new Report instance without setting required fields, e.g., ReportName, ReportType, StartDate, EndDate, FilePath
            var report = new Report
            {
                // Missing required properties intentionally to trigger validation errors
            };

            // Act
            // Creating a list to store validation results
            var validationResults = new List<ValidationResult>();
            // Setting up a validation context for the report instance, which helps validate properties with specific rules
            var validationContext = new ValidationContext(report);
            // Performing validation on the report object; the TryValidateObject method populates validationResults if there are errors
            var isValid = Validator.TryValidateObject(report, validationContext, validationResults, true);

            // Assert
            // Verifying that the report is not valid, as expected
            Assert.IsFalse(isValid);
            // Checking that there are exactly 4 validation errors for the missing fields
            Assert.AreEqual(4, validationResults.Count); // Expected 4 errors for missing fields: ReportName, ReportType, StartDate, EndDate, FilePath
        }

        // Test to verify that a Report with an EndDate earlier than StartDate triggers validation errors
        [Test]
        public void Report_WithEndDateEarlierThanStartDate_ShouldHaveValidationErrors()
        {
            // Arrange
            // Creating a Report with valid ReportName, ReportType, and FilePath but setting an invalid EndDate (earlier than StartDate)
            var report = new Report
            {
                ReportName = "Monthly Report",
                ReportType = "Summary",
                StartDate = DateTime.Now,
                EndDate = DateTime.Now.AddDays(-1), // Intentionally invalid EndDate (earlier than StartDate)
                FilePath = "report.pdf" // Valid file path with correct extension
            };

            // Act
            // Setting up validation context and capturing validation results
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(report);
            var isValid = Validator.TryValidateObject(report, validationContext, validationResults, true);

            // Assert
            // Verifying that validation fails due to invalid EndDate
            Assert.IsFalse(isValid);
            // Checking for a specific validation error indicating that EndDate must be after StartDate
            Assert.IsTrue(validationResults.Exists(v => v.ErrorMessage == "End Date must be after Start Date."));
        }

        // Test to verify that a Report with an invalid file extension in the FilePath triggers validation errors
        [Test]
        public void Report_WithInvalidFileExtension_ShouldHaveValidationErrors()
        {
            // Arrange
            // Creating a Report instance with valid ReportName, ReportType, StartDate, and EndDate but an invalid file extension in FilePath
            var report = new Report
            {
                ReportName = "Annual Report",
                ReportType = "Financial",
                StartDate = DateTime.Now.AddMonths(-1),
                EndDate = DateTime.Now,
                FilePath = "report.txt" // Invalid file extension; should trigger validation error
            };

            // Act
            // Setting up validation context and capturing validation results
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(report);
            var isValid = Validator.TryValidateObject(report, validationContext, validationResults, true);

            // Assert
            // Verifying that the Report fails validation due to the invalid file extension in FilePath
            Assert.IsFalse(isValid);
            // Checking for a specific validation error indicating that the FilePath must end with .pdf, .docx, or .xlsx
            Assert.IsTrue(validationResults.Exists(v => v.ErrorMessage == "File Path must be a .pdf, .docx, or .xlsx file."));
        }
    }
}
