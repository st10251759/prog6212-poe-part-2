﻿/*
 --------------------------------Student Information----------------------------------
 STUDENT NO.: ST10251759
 Name: Cameron Chetty
 Course: BCAD Year 2
 Module: Programming 2B
 Module Code: CLDV6212
 Assessment: Portfolio of Evidence (POE) Part 2
 Github repo link: https://github.com/st10251759/prog6212-poe-part-2
 --------------------------------Student Information----------------------------------

 ==============================Code Attribution==================================

 Attributes
 Author: Fatima Shaik
 Link: https://github.com/fb-shaik/PROG6212-Group1-2024/tree/main/TaskManager_Attributes_demo/TaskManager_Attributes_demo
 Date Accessed: 11 October 2024

 MVC APP
 Author: Fatima Shaik
 Link: https://github.com/fb-shaik/PROG6212-Group1-2024/blob/main/EmployeeLeaveManagement_G1.zip
 Date Accessed: 11 October 2024

 ==============================Code Attribution==================================

 */

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ST10251759_PROG6212_POE.Models;

namespace ST10251759_PROG6212_POE_Tests
{
    [TestFixture]
    public class DocumentTests
    {
        [Test]
        public void Document_ValidProperties_ShouldBeValid()
        {
            // Arrange
            // Create a Document object with valid properties
            var document = new Document
            {
                DocumentName = "Test Document", // Valid name
                FilePath = "C:/Users/chett/source/repos/ST10251759_PROG6212_POE/wwwroot/uploads/161c81d7-50ab-4151-90b2-5e558a88d5f1_Test Document 2.pdf", // Valid file path
                UploadedOn = DateTime.Now, // Current date is valid
                ClaimId = 1 // Valid claim ID
            };

            // Act
            // Validate the document model
            var validationResults = ValidateModel(document);

            // Assert
            // Assert that there are no validation errors
            Assert.IsEmpty(validationResults);
        }

        [Test]
        public void Document_EmptyDocumentName_ShouldBeInvalid()
        {
            // Arrange
            // Create a Document object with an empty DocumentName
            var document = new Document
            {
                DocumentName = string.Empty, // Invalid: DocumentName is required
                FilePath = "C:/Users/chett/source/repos/ST10251759_PROG6212_POE/wwwroot/uploads/161c81d7-50ab-4151-90b2-5e558a88d5f1_Test Document 2.pdf", // Valid file path
                UploadedOn = DateTime.Now, // Current date is valid
                ClaimId = 1 // Valid claim ID
            };

            // Act
            // Validate the document model
            var validationResults = ValidateModel(document);

            // Assert
            // Assert that there are validation errors and check the error message
            Assert.IsNotEmpty(validationResults);
            Assert.AreEqual("Document Name is required.", validationResults[0].ErrorMessage);
        }

        [Test]
        public void Document_EmptyFilePath_ShouldBeInvalid()
        {
            // Arrange
            // Create a Document object with an empty FilePath
            var document = new Document
            {
                DocumentName = "Test Document", // Valid name
                FilePath = string.Empty, // Invalid: FilePath is required
                UploadedOn = DateTime.Now, // Current date is valid
                ClaimId = 1 // Valid claim ID
            };

            // Act
            // Validate the document model
            var validationResults = ValidateModel(document);

            // Assert
            // Assert that there are validation errors and check the error message
            Assert.IsNotEmpty(validationResults);
            Assert.AreEqual("File Path is required.", validationResults[0].ErrorMessage);
        }

        [Test]
        public void Document_ExceededDocumentNameMaxLength_ShouldBeInvalid()
        {
            // Arrange
            // Create a Document object with a DocumentName that exceeds the maximum length
            var document = new Document
            {
                DocumentName = new string('A', 256), // Invalid: Exceeds max length of 255
                FilePath = "C:/Documents/TestDocument.pdf", // Valid file path
                UploadedOn = DateTime.Now, // Current date is valid
                ClaimId = 1 // Valid claim ID
            };

            // Act
            // Validate the document model
            var validationResults = ValidateModel(document);

            // Assert
            // Assert that there are validation errors and check the error message
            Assert.IsNotEmpty(validationResults);
            Assert.AreEqual("The field DocumentName must be a string or array type with a maximum length of '255'.", validationResults[0].ErrorMessage);
        }

        private IList<ValidationResult> ValidateModel(Document document)
        {
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(document); // Create a validation context for the document
            Validator.TryValidateObject(document, validationContext, validationResults, true); // Perform validation
            return validationResults; // Return the list of validation results
        }
    }
}